<script type="text/javascript">
function jsFunction(){
alert('Selamat Datang Di PPDB Online Sekolah Sukma Bangsa Bireuen\nDisarankan Menggunakan Layar Landscape Untuk Tampilan Yang Lebih Baik');
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
