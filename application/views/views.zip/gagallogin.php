<script type="text/javascript">
function jsFunction(){
alert('Gagal, Silahkan Login Kembali!');
window.location.href = "./login";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
